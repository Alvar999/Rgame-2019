# getspawninfo
Get spawn info function

# Functions
```Pawn
GetSpawnInfo(playerid, &team = NO_TEAM, &skin = 0,
             &Float:x = 0.0, &Float:y = 0.0, &Float:z = 0.0, &Float:rotation = 0.0,
             &weapon1 = 0, &weapon1_ammo = 0, &weapon2 = 0, &weapon2_ammo = 0, &weapon3 = 0, &weapon3_ammo = 0)
```
