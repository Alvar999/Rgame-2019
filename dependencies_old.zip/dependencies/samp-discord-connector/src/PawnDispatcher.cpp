#include "PawnDispatcher.hpp"


void PawnDispatcher::Dispatch(Function_t &&func)
{
	std::lock_guard<std::mutex> lock_guard(m_QueueMtx);
	return m_Queue.push(std::move(func));
}

void PawnDispatcher::Process()
{
	std::lock_guard<std::mutex> lock_guard(m_QueueMtx);
	while (m_Queue.empty() == false)
	{
		m_Queue.front()();
		m_Queue.pop();
	}
}
