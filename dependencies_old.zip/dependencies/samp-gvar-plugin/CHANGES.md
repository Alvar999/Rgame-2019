SA-MP GVar Plugin
=================

v1.3
----

- Made indexes local to each unique ID
- Slightly improved GetGVarsUpperIndex

v1.2
----

- Added case-insensitive matching
- Fixed a bug with index assignment

v1.1
----

- Vastly improved lookup speeds by implementing a hash table
- Added an extra optional parameter to all of the natives

v1.0
----

- Initial release
